import { Link } from 'react-router-dom';
import BackButton from '../components/BackButton';
import chatbot from "../assets/images/chatbot.png";
import lampada from "../assets/images/ideia.png";


export default function Tutorial() {
  return (
    <div className="p-4 space-y-6">
      {/* Cabeçalho */}
      <div className="text-center">
        <h1 className="text-2xl font-bold text-gray-800 mb-2">Tutorial do VisuAll</h1>
        <p className="text-gray-600">Aprenda como usar nosso sistema de forma simples e prática</p>
      </div>

      {/* Botão voltar */}
      <BackButton />

      {/* Container do vídeo centralizado */}
      <div className="flex flex-col items-center justify-center min-h-[60vh] bg-white rounded-lg shadow-sm p-8">
        {/* Placeholder para o vídeo */}
        <div className="w-full max-w-4xl aspect-video bg-gray-100 rounded-lg border-2 border-dashed border-gray-300 flex flex-col items-center justify-center">
          {/* Ícone de vídeo */}
          <div className="w-20 h-20 text-gray-400 mb-4">
            <svg fill="currentColor" viewBox="0 0 24 24" className="w-full h-full">
              <path d="M8 5v14l11-7z"/>
            </svg>
          </div>
          
          {/* Texto placeholder */}
          <h3 className="text-xl font-semibold text-gray-600 mb-2">Vídeo Tutorial</h3>
          <p className="text-gray-500 text-center max-w-md">
            O vídeo tutorial será inserido aqui após a gravação. 
            Este espaço está reservado para o conteúdo educativo sobre como usar o VisuAll.
          </p>
          
          {/* Informações técnicas para desenvolvimento */}
          <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <h4 className="font-medium text-blue-800 mb-2">Para desenvolvedores:</h4>
            <div className="text-sm text-blue-700 space-y-1">
              <p>• Substitua este placeholder por um elemento &lt;video&gt; ou iframe</p>
              <p>• Formatos recomendados: MP4, WebM</p>
              <p>• Considere adicionar controles de acessibilidade</p>
              <p>• Inclua legendas para melhor acessibilidade</p>
            </div>
          </div>
        </div>

        {/* Controles do vídeo (placeholder) */}
        <div className="mt-6 flex flex-wrap gap-4 justify-center">
          <button 
            disabled
            className="bg-gray-300 text-gray-500 px-6 py-3 rounded-lg font-medium cursor-not-allowed flex items-center space-x-2"
          >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M8 5v14l11-7z"/>
            </svg>
            <span>Reproduzir</span>
          </button>
          
          <button 
            disabled
            className="bg-gray-300 text-gray-500 px-6 py-3 rounded-lg font-medium cursor-not-allowed flex items-center space-x-2"
          >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z"/>
            </svg>
            <span>Pausar</span>
          </button>
          
          <button 
            disabled
            className="bg-gray-300 text-gray-500 px-6 py-3 rounded-lg font-medium cursor-not-allowed flex items-center space-x-2"
          >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z"/>
            </svg>
            <span>Tela cheia</span>
          </button>
        </div>
      </div>

      {/* Informações adicionais */}
      <div className="bg-teal-50 rounded-lg p-6">
        <h2 className="text-lg font-semibold text-teal-800 mb-3 flex items-center">
          <img className="w-6 h-6" src={lampada} alt="icone lampada" />
          O que você aprenderá
        </h2>
        
        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <h3 className="font-medium text-teal-700">Funcionalidades básicas:</h3>
            <ul className="text-teal-600 text-sm space-y-1">
              <li>• Como navegar pelo aplicativo</li>
              <li>• Como adicionar um novo lembrete</li>
              <li>• Como ouvir seus lembretes</li>
              <li>• Como compartilhar informações</li>
            </ul>
          </div>
          
          <div className="space-y-2">
            <h3 className="font-medium text-teal-700">Recursos de acessibilidade:</h3>
            <ul className="text-teal-600 text-sm space-y-1">
              <li>• Como usar o assistente de voz</li>
              <li>• Como ajustar o tamanho da fonte</li>
              <li>• Como navegar com o teclado</li>
              <li>• Como obter ajuda e suporte</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Botões de ação */}
      <div className="flex flex-col sm:flex-row gap-3 justify-center">
        <Link 
          to="/" 
          className="bg-teal-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-teal-700 transition-colors duration-200 text-center"
        >
          Voltar ao início
        </Link>
        
        <Link 
          to="/instrucoes" 
          className="border border-teal-600 text-teal-600 px-6 py-3 rounded-lg font-medium hover:bg-teal-50 transition-colors duration-200 text-center"
        >
          Ver instruções para consultas
        </Link>
      </div>

      {/* Recursos de acessibilidade */}
      <div className="bg-blue-50 rounded-lg p-4">
        <h2 className="text-lg font-semibold text-blue-800 mb-2 flex items-center">
          <img className="w-5 h-5 mr-2" src={chatbot} alt="icone chatbot" />
          Dica de Acessibilidade
        </h2>
        <p className="text-blue-700 text-sm">
          Quando o vídeo estiver disponível, você poderá usar as teclas de espaço para pausar/reproduzir, 
          setas para navegar e F para tela cheia. O vídeo incluirá legendas e descrição de áudio.
        </p>
      </div>
    </div>
  );
}
